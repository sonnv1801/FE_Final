import React from 'react';
import './style.css';
function Repost() {
  return (
    <div>
      <div className="repost">
        <div className="repost-title">Voucher today</div>
        <img
          src="https://clickbuy.com.vn/uploads/2023/02/bpl-dat-hang-galaxy-s23-01-2.png"
          alt="..."
        ></img>
        <img
          src="https://clickbuy.com.vn/uploads/2023/02/bpl-valentine-day-iphone-01.png"
          alt="..."
        ></img>
        <img
          src="https://clickbuy.com.vn/uploads/2022/10/bpl-apple-watch-uu-dai-to-01.png"
          alt="..."
        ></img>
      </div>
    </div>
  );
}

export default Repost;
