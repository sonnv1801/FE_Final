import React from 'react';
import { Link } from 'react-router-dom';
import './style.css';
export const MenuShop = () => {
  return (
    <div className="menu-shop">
      <ul>
        <li>
          <Link to="/">Sam Sung S23 Series</Link>
        </li>
        <li>
          <Link to="/">Sam Sung S23 Series</Link>
        </li>
        <li>
          <Link to="/">Sam Sung S23 Series</Link>
        </li>
        <li>
          <Link to="/">Sam Sung S23 Series</Link>
        </li>
        <li>
          <Link to="/">Sam Sung S23 Series</Link>
        </li>
        <li>
          <Link to="/">Sam Sung S23 Series</Link>
        </li>
        <li>
          <Link to="/">Sam Sung S23 Series</Link>
        </li>
        <li>
          <Link to="/">Sam Sung S23 Series</Link>
        </li>
        <li>
          <Link to="/">Sam Sung S23 Series</Link>
        </li>
      </ul>
    </div>
  );
};
