import './index.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Footer from './components/footer/Footer';
import HomePage from './pages/home/hompage/HomePage';
import Shop from './pages/home/shop/Shop';
import Carousel from './components/carousel/Carousel';
import Menu from './components/menu/Menu';
import MiniCard from './components/minicard/MiniCard';
import Clock from './components/flashsale/Clock';
import Card from './components/cards/Card';
import ProductDetail from './pages/productDetail/ProductDetail';
import { Payment } from './pages/home/payment/Payment';
import Navbar from './components/navbar/Navbar';
import Login from './pages/home/login/Login';
import NotFound from './pages/home/notfound/NotFound';
import Register from './pages/home/register/Register';
import { Order } from './pages/home/order/Order';
function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/product-detail" element={<ProductDetail />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/order" element={<Order />} />
          <Route path="/card" element={<Card />} />
          {/* <Route path="/footer" element={<Footer />} /> */}
          <Route path="/carousel" element={<Carousel />} />
          <Route path="/menu" element={<Menu />} />
          <Route path="/minicard" element={<MiniCard />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Footer />
      </Router>
    </div>
  );
}

export default App;
